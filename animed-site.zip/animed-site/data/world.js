/* WORLD FILE: things that belong to the whole game, not one region.
   1) the prologue every new traveler sees once
   2) the list of sealed regions shown on the realm screen (names are working drafts)
   Region files (neurology.js, ...) are loaded after this file and add themselves with Animed.addRegion(). */
window.Animed=window.Animed||{regions:[]};
Animed.addRegion=function(r){ Animed.regions.push(r); };

/* who: narrator | you | pulse | hush | any character key defined in a region's "characters".
   {you} is replaced by the traveler's name. m (Pulse only): idle | happy | oops */
Animed.prologue=[
 {who:'narrator',t:'The last thing you remember is a long night, a cold cup of tea, and a sound you could not place. A bell, very far away.'},
 {who:'narrator',t:'Then the floor is gone. You fall slowly, the way you fall in dreams, through a sky full of drifting lights.'},
 {who:'narrator',t:'You land on a road made of light. It hums under your feet like a held note.'},
 {who:'pulse',m:'happy',t:'You came through! Careful, the first step is the strangest. I am Pulse, a lamplighter spirit. Small, I know. The light makes up for it.'},
 {who:'you',t:'Where am I? Is this a dream?'},
 {who:'pulse',m:'idle',t:'Close. This is Lumara, the realm between waking and sleeping. Everything that moves, remembers or feels here travels along roads like this one. We call them the Lantern Roads.'},
 {who:'pulse',m:'oops',t:'But the lanterns are going dark, one by one. Travelers freeze mid-step. Messengers forget where they were going. We call it the Hush.'},
 {who:'you',t:'Why am I here?'},
 {who:'pulse',m:'idle',t:'Because of what you carry. An old art Lumara has no word for. Reading what a body is telling you: where the trouble is, what is causing it, and what to do next.'},
 {who:'pulse',m:'happy',t:'Walk the roads with me, {you}. Meet the people along them. Listen to their stories. We might light them again.'}
];

Animed.sealed=[
 {name:'The Ember Forge',system:'Cardiology'},
 {name:'The Windless Reach',system:'Pulmonology'},
 {name:'The Tidal Vaults',system:'Nephrology'},
 {name:'The Gilded Orchard',system:'Gastroenterology'},
 {name:'The Clockwork Spire',system:'Endocrinology'}
];
