Put your own character images here (PNG). See README.md, section "Use your own character images".
Names: hero-f.png, hero-m.png, pulse.png, npc-<key>.png (for example npc-orrin.png).
